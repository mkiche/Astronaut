package com.mkiche.astronaut;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.Toast;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

public class MainActivity extends AppCompatActivity {

    SQLiteDatabase eventsDB;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        try{
            eventsDB = this.openOrCreateDatabase("Astronaut", MODE_PRIVATE, null);

            eventsDB.execSQL("CREATE TABLE IF NOT EXISTS dreams (tag VARCHAR, dreamdate DATE, description VARCHAR, id INTEGER PRIMARY KEY)");

        } catch (Exception e){
            Log.i("Error Creating DB",e.getMessage());
        }
    }

    public void saveDream(View view){

        EditText strDreamTitle = (EditText) findViewById(R.id.txtDreamTitle);
        DatePicker dreamDate = (DatePicker) findViewById(R.id.datePicker);
        EditText strDreamDescr =(EditText)  findViewById(R.id.txtDream);

        int   day  = dreamDate.getDayOfMonth();
        int   month= dreamDate.getMonth();
        int   year = dreamDate.getYear();
        Calendar calendar = Calendar.getInstance();
        calendar.set(year, month, day);

        SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy");
        String formatedDate = sdf.format(calendar.getTime());


        if(strDreamTitle.getText().toString().equals("")){
            Toast.makeText(this, "Please give the dream a title" , Toast.LENGTH_SHORT).show();
            return;
        }
        if(strDreamDescr.getText().toString().equals("")){
            Toast.makeText(this, "Please describe the dream you had" , Toast.LENGTH_SHORT).show();
            return;
        }


        try {

            eventsDB.execSQL("INSERT INTO dreams (tag, dreamdate, description) VALUES ('"+strDreamTitle.getText().toString()+"','"+formatedDate +"','"+strDreamDescr.getText().toString()+"' )");
            strDreamTitle.setText("");
            strDreamDescr.setText("");
            Toast.makeText(this, "Dream saved successfully" , Toast.LENGTH_SHORT).show();
        }catch (Exception e){
           e.printStackTrace();
        }


    }

    public void searchDream(View view){
        EditText strDreamTitle = (EditText) findViewById(R.id.txtDreamTitle);
        DatePicker dreamDate = (DatePicker) findViewById(R.id.datePicker);
        EditText strDreamDescr =(EditText)  findViewById(R.id.txtDream);

        int   day  = dreamDate.getDayOfMonth();
        int   month= dreamDate.getMonth();
        int   year = dreamDate.getYear();
        Calendar calendar = Calendar.getInstance();
        calendar.set(year, month, day);

        SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy");
        String formatedDate = sdf.format(calendar.getTime());


        String sqlQuery;

        if(!strDreamTitle.getText().toString().equals("")  ){
            sqlQuery = "SELECT  tag, dreamdate, description FROM dreams where tag='"+ strDreamTitle.getText().toString() +"'";
        }
        else if(!strDreamDescr.getText().toString().equals("")){
            sqlQuery = "SELECT  tag, dreamdate, description FROM dreams where description like '%"+ strDreamDescr.getText().toString() +"%'";
        } else {
            sqlQuery = "SELECT  tag, dreamdate, description FROM dreams where dreamdate='"+ formatedDate +"'";
        }

        Log.i("querys",sqlQuery);

        try {
            Cursor c = eventsDB.rawQuery(sqlQuery, null);

            int tagIndex = c.getColumnIndex("tag");
            int dreamDateIndex = c.getColumnIndex("dreamdate");
            int descrIndex = c.getColumnIndex("description");

            c.moveToFirst();

            if (c != null) {

                Log.i("Tag", c.getString(tagIndex));
                Log.i("Date", c.getString(dreamDateIndex));
                Log.i("Description", c.getString(descrIndex));

                strDreamTitle.setText(c.getString(tagIndex));
                strDreamDescr.setText(c.getString(descrIndex));

                //Date date = sdf.parse(c.getString(dreamDateIndex)));

            } else {
                Toast.makeText(this, "Sorry, no such dream exists!" , Toast.LENGTH_SHORT).show();
            }

        }catch (Exception e){
            e.printStackTrace();
        }

    }

}
